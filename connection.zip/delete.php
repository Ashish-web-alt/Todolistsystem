<?php
include "connection.php";
// Delete record logic
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql= "DELETE FROM employee WHERE id=$id";
    $result=mysqli_query($conn,$sql);
    if ($result) {
       header('location:todolist.php');
       
    } else {
        die(mysqli_error($conn));
    }
}
?>