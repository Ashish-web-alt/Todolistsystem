<?php
// Include database connection file
include('connection.php');

// Fetch the 'id' from the GET request to identify which record to edit
if (isset($_GET['id'])) {
    $id = $_GET['id'];  // Get the ID from the URL query parameter

    // Correct SQL query to fetch record by ID
    $sql = "SELECT * FROM `employee` WHERE id=$id";
    $result = mysqli_query($conn, $sql);

    // Check if the query was successful and contains results
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        if ($row) {
            // Fetch the data for the form
            $id = $row['id'];
            $username = $row['username'];
            $pass = $row['pass'];
            $time = $row['time_allocated'];
            $deadline = $row['deadline'];
            $task = $row['task'];
        } else {
            // If no results are found, handle the error
            echo "No record found with the given ID.";
        }
    } else {
        // Handle SQL error
        echo "Error: " . mysqli_error($conn);
    }
} else {
    // If 'id' is not set in the URL, handle the error
    echo "No ID provided for editing.";
    exit;
}

// Handle form submission when user submits the edit form
if (isset($_POST['update'])) {
    // Get form data
    $user = $_POST['username'];
    $pass = $_POST['password'];
    $time_allocated = $_POST['time-allocated'];
    $deadline = $_POST['deadline'];
    $task = $_POST['new-task'];

    // Update the record with the provided data
    $sql = "UPDATE `employee` SET username='$user', pass='$pass', time_allocated='$time_allocated', deadline='$deadline', task='$task' WHERE id=$id";

    $result = mysqli_query($conn, $sql);

    // Handle update result
    if ($result) {
        echo "Record updated successfully.";
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Task</title>
</head>
<body>
    <!-- Modal for Editing Task -->
    <div id="login-container" class="modal">
        <div class="modal-content">
            <span class="close-btn">&times;</span>
            <form id="task-form" method="POST">
                <h2>Edit User & Task Details</h2>

                <!-- Hidden input to hold the ID -->
                <input type="hidden" name="id" id="id" value="<?php echo isset($id) ? $id : ''; ?>" />

                <div class="form-group">
                    <input type="text" name="username" id="username" placeholder="Username" required value="<?php echo isset($username) ? $username : ''; ?>" />
                </div>

                <div class="form-group">
                    <input type="password" name="password" id="password" placeholder="Password" required value="<?php echo isset($pass) ? $pass : ''; ?>" />
                </div>

                <div class="form-group">
                    <input type="text" name="new-task" id="new-task" placeholder="Task" required value="<?php echo isset($task) ? $task : ''; ?>" />
                </div>

                <div class="form-group">
                    <input type="number" name="time-allocated" id="time-allocated" placeholder="Time Allocated (minutes)" required value="<?php echo isset($time) ? $time : ''; ?>" />
                </div>

                <div class="form-group">
                    <input type="date" name="deadline" id="deadline" required value="<?php echo isset($deadline) ? $deadline : ''; ?>" />
                </div>

                <div>
                    <button type="submit" name="update" class="submit-btn">Update</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
