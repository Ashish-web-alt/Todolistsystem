<?php 

$conn = new mysqli('localhost', 'root', '', 'task');

// Check connection
if (!$conn) {
    die(mysqli_error($conn));
}
