<?php
include('connection.php');
$servername = "localhost";  // or your server name
$username = "root";         // your MySQL username
$password = "";             // your MySQL password (leave empty if no password)

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to create database
$sql = "CREATE DATABASE task";

if ($conn->query($sql) === TRUE) {
    echo "Database 'task' created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

// Close the connection
$conn->close();
?>
