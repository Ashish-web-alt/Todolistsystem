<?php
// Include database connection file (Make sure your DB connection is correct)
include('connection.php');

if (isset($_POST['submit'])) {
    // Get form data
    $user = $_POST['username'];
    $pass = $_POST['password'];
    $time_allocated = $_POST['time-allocated'];
    $deadline = $_POST['deadline'];
    $task = $_POST['new-task'];
    $id = $_POST['id'];

    // Insert new record
    $sql = "INSERT INTO employee (id, username, pass ,time_allocated, deadline, task) 
            VALUES ('$id','$user', '$pass', '$time_allocated', '$deadline', '$task')";
    
    // Execute the query
    if (mysqli_query($conn, $sql)) {
        // Fetch the updated records to display in the table
        $result = mysqli_query($conn, "SELECT * FROM employee");

        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $id = $row['id'];
                $username = $row['username'];
                $pass = $row['pass'];
                $time = $row['time_allocated'];
                $deadline = $row['deadline'];
                $task = $row['task'];

                echo "<tr>
                        <td>$id</td>
                        <td>$username</td>
                        <td>$pass</td>
                        <td>$time</td>
                        <td>$deadline</td>
                        <td>$task</td>
                        <td>
                            <a href='edit.php?id=$id' class='edit-btn'>Edit</a>
                            <a href='delete.php?id=$id' class='delete-btn'>Delete</a>
                        </td
                    </tr>";
            }
        }
    } else {
        die(mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Management</title>
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            color: #333;
        }

        header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .nav-bar {
            background-color: #333;
            padding: 10px 0;
            text-align: center;
        }

        .nav-bar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            padding: 12px 20px;
            margin: 0 15px;
            border-radius: 30px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .nav-bar a:hover {
            background-color: #45a049;
            transform: scale(1.1);
        }

        .container {
            width: 80%;
            margin: 30px auto;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        td {
            background-color: #f9f9f9;
        }

        td a {
            color: #4CAF50;
            text-decoration: none;
            font-weight: bold;
            padding: 6px 12px;
            border-radius: 20px;
            background-color: #f1f1f1;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        td a:hover {
            background-color: #4CAF50;
            color: white;
        }

        .edit-btn {
            background-color: #4CAF50;
            color: white;
        }

        .delete-btn {
            background-color: #f44336;
            color: white;
            margin-left: 10px;
        }

        .edit-btn:hover {
            background-color: #45a049;
        }

        .delete-btn:hover {
            background-color: #e53935;
        }

        /* Modal Styling */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #fff;
            padding: 30px;
            width: 60%;
            max-width: 600px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            position: relative;
        }

        .close-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 30px;
            color: #ccc;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .close-btn:hover {
            color: #333;
        }

        .form-group input {
            width: 100%;
            padding: 14px;
            margin: 12px 0;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .submit-btn {
            background-color: #4CAF50;
            color: white;
            padding: 14px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #45a049;
        }

    </style>

</head>
<body>

<header>
    <h1>Task Management</h1>
</header>

<div class="nav-bar">
    <a href="#" id="home-link">Home</a>
    <a href="#" id="login-link">Login</a>
</div>

<div class="container">
    <h2>Employee Records</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Password</th>
                <th>Time Allocated</th>
                <th>Deadline</th>
                <th>Task</th>
                <th>Actions</th> <!-- New Actions column -->
            </tr>
        </thead>
        <tbody>
            <!-- Data from database will be displayed here -->
             <!-- Modal for Editing Task -->
<div id="login-container" class="modal">
    <div class="modal-content">
        <span class="close-btn">&times;</span>
        <form id="task-form" method="POST">
            <h2>Edit User & Task Details</h2>

            <input type="hidden" name="id" id="id" value="" />

            <div class="form-group">
                <input type="text" name="username" id="username" placeholder="Username" required />
            </div>

            <div class="form-group">
                <input type="password" name="password" id="password" placeholder="Password" required />
            </div>

            <div class="form-group">
                <input type="text" name="new-task" id="new-task" placeholder="Task" required />
            </div>

            <div class="form-group">
                <input type="number" name="time-allocated" id="time-allocated" placeholder="Time Allocated (minutes)" required />
            </div>

            <div class="form-group">
                <input type="date" name="deadline" id="deadline" required />
            </div>

            <div>
                <button type="submit" name="submit" class="submit-btn">Submit</button>
            </div>
        </form>
    </div>
</div>
<script>
    // Handle Modal and Form Actions
    const loginContainer = document.getElementById("login-container");
    const loginLink = document.getElementById("login-link");
    const closeBtn = document.querySelector(".close-btn");

    loginLink.addEventListener("click", function (event) {
        event.preventDefault();
        loginContainer.style.display = "flex";
    });

    closeBtn.addEventListener("click", function () {
        loginContainer.style.display = "none";
    });

    window.addEventListener("click", function (event) {
        if (event.target === loginContainer) {
            loginContainer.style.display = "none";
        }
    });
</script>

</body>
</html>


<?php
// Include database connection file
include('connection.php');

// Fetch the records from the database and display them in the table
$result = mysqli_query($conn, "SELECT * FROM employee");

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Fetch each record and display
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['username']}</td>
                <td>{$row['pass']}</td>
                <td>{$row['time_allocated']}</td>
                <td>{$row['deadline']}</td>
                <td>{$row['task']}</td>
                <td>
                    <!-- Edit and Delete links with correct dynamic ID -->
                    <a href='edit.php?id={$row['id']}' class='edit-btn'>Edit</a>
                    <a href='delete.php?id={$row['id']}' class='delete-btn'>Delete</a>
                </td>
            </tr>";
    }
} else {
    echo "Error fetching data: " . mysqli_error($conn);
}
?>


        </tbody>
    </table>
</div>

</body>
</html>
