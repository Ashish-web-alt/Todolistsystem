<?php
include('connection.php');
$servername = "localhost";  // MySQL server name
$username = "root";         // MySQL username
$password = "";             // MySQL password (leave empty if no password)
$dbname = "task";           // The database where the table will be created

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to create the 'employee' table
$sql = "CREATE TABLE employee (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    pass VARCHAR(255) NOT NULL,
    time_allocated INT(11) NOT NULL,
    deadline DATETIME NOT NULL,
    task TEXT NOT NULL
)";

// Execute the query and check if the table was created successfully
if ($conn->query($sql) === TRUE) {
    echo "Table 'employee' created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Close the connection
$conn->close();
?>
